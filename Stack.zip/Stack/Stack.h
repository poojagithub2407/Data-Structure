#ifndef STACK_H
#define STACK_H

class Stack
{
	int top,size;
	int *pStack;
	public:
		Stack();
		Stack(int);
		bool IsEmpty();
		bool IsFull();
		bool Push(int);
		bool Pop(int&);
		bool Peek(int&);
		void Display();
		~Stack();
	
};

#endif
