#include <iostream>
#include"Stack.h";
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	int ch=0;
	Stack st(5);
	while(ch!=4)
	{
		cout<<"\n\t\t1)Push";
		cout<<"\n\t\t2)Pop";
		cout<<"\n\t\t3)Display";
		cout<<"\n\t\t4)Exit";
		cout<<"\nEnter the your choice: ";
		cin>>ch;
		switch(ch)
		{
			case 1:
			{
			
				    int data;
				    cout<<"\nEnter Element into Stack:";
				    cin>>data;
				    if(st.Push(data))
				    {
					    cout<<"\nElement insert into Stack is Successfully";
				    }
				    else
				    {
					     cout<<"\nStack is Overflow";
				    }
				    
			   	}
			break;   	
		    case 2:
			{
		    	    
					int  data;
					if(st.Pop(data))
					{
						cout<<"\n"<<data<<"is popped";
					}
					else
					{
						cout<<"\nStack is Empty";
					}
					
				    }
			 break;
			 case 3:
			 	  st.Display();
			 break;
			 case 4:
			 	   cout<<"\nEnd of program";
			 	   break;
			 default:
			         cout<<"\nInvalid Choice";
					 break; 	   
				 
			      }
		    	
		}
		return 0;
	
}
