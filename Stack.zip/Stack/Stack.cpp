#include "Stack.h"
#include<iostream>
using namespace std;
////////////////////////////////
Stack::Stack()
{
	size=0;
	top=-1;
	pStack=NULL;
}
///////////////////////////////
Stack::Stack(int s)
{
	size=s;
	top=-1;
	pStack=new int[size]; 
}
//////////////////////////////
bool Stack:: IsEmpty()
{
	if(top==-1)
	{
		return true;
	}
	else
	{
		return false;
	}
	
}
////////////////////////////////
bool Stack:: IsFull()
{
	if(top==size-1)
	{
		return true;
	}
	else
	{
		return false;
	}
}
///////////////////////////////		
bool Stack::Push(int data)
{
	if(IsFull())
	{
		return false;
	}
	else
	{
		pStack[++top]=data;
		return true;
	}
}
////////////////////////////////
bool Stack:: Pop(int &t)
{
	if(IsEmpty())
	{
		return false;
	}
	else
	{
		t=pStack[top--];
		return true;
	}
	
}
///////////////////////////////
bool Stack:: Peek(int &t)
{
	if(IsEmpty())
	{
		return false;
	}
	else
	{
		t=pStack[top];
		return true;
	}
}
//////////////////////////////
Stack::~Stack()
{
	if(pStack!=NULL)
	{
		delete []pStack;
	}
}
 void Stack::Display()
 {
 	int i;
 	if(IsEmpty())
 	{
 		cout<<"\nNo Element ";
	 }
	 else
	 {
	 	for(i=top;i>=0;i--)
	 	{
	 		cout<<"\t"<<pStack[i];
		 }
	 }
 }
