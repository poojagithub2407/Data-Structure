#ifndef LQUEUE_H
#define LQUEUE_H

class Lqueue
{
	int rear,front,size;
	int *pQueue;
	public:
		Lqueue();
		Lqueue(int);
		bool IsFull();
		bool IsEmpty();
		bool EnQueue(int);
		bool DeQueue(int&);
		~Lqueue();
		void Display();
};

#endif
