#include "Lqueue.h"
#include<iostream>
using namespace std;
Lqueue::Lqueue()
{
	size=0;
	pQueue=NULL;
	rear=front=-1;
}
Lqueue::Lqueue(int s)
{
	size=s;
	rear=front=-1;
	pQueue=new int[size];
}
bool Lqueue:: IsEmpty()
{
	if(rear==-1 && front==-1)
    {
    	return true;
	}
	else
	{
		return false;
	}
	
}
bool Lqueue::IsFull()
{
	if(rear==size-1 )
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool Lqueue::EnQueue(int data)
{
	if(IsFull())
	{
		front=rear=0;
	}
	else
	{
		++rear;
	}
	pQueue[rear]=data;
	return true;
}
bool Lqueue :: DeQueue(int& data)
{
	if(!IsEmpty())
	{
		data=pQueue[front];
		if(front==rear)
		{
			front=rear=-1;
		}
		else
		{
			front++;
		}
		return true;
	}
	else
	{
		return false;
	}
}

void Lqueue:: Display()
{
	int i;
	if(!IsEmpty())
	{
		for(i=front;i<=rear;i++)
		{
			cout<<"\t"<<pQueue[i];
		}
	}
	else
	{
		cout<<"\nNo Element to display";
	}
}
Lqueue::~Lqueue()
{
	if(pQueue!=NULL)
	{
		delete[]pQueue;
	}
}
