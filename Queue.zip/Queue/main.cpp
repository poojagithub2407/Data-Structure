#include <iostream>
#include "Lqueue.h"
#include<iostream>
using namespace std;

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	int choice=0;
	Lqueue qt(5);
	while(choice!=4)
	{
		cout<<"\n\t\t1)EnQueue";
		cout<<"\n\t\t2)DeQueue";
		cout<<"\n\t\t3)Display";
		cout<<"\n\t\t4)Exit";
		cout<<"\nEnter your choice:";
		cin>>choice;
		switch(choice)
		{
			case 1:
				{
			      int data;
				  cout<"\nEnter the data you want to insert:";
				  cin>>data;
				  if(qt.EnQueue(data))	
				  {
				  	cout<<"\nSuccess";
				  }	
				  else
				  {
				  	cout<<"\nQueue is Overflow";
				  }
				}
			break;
			case 2:
				{
					int data;
					if(qt.DeQueue(data))
					{
						cout<<"\n"<<data<<"popped.";
					}
					else
					{
						cout<<"Queue is Empty";
					}
					
				}
			break;
			case 3:
				 qt.Display();
			break;
			case 4:
				 cout<<"\nEnd Program";
				break;
			default:
				cout<<"\nInvalid choice";
			break;	
		}
	}
	return 0;
}
